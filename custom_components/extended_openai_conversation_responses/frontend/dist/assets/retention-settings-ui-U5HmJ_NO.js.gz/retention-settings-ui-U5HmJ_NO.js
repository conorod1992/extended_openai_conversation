import{R as e,gt as t}from"./management-core-C48VwbMP.js";import{f as n}from"./management-page-drafts-B_Zbz55k.js";var r=[[`usage_request_retention_days`,`Keep request details for`],[`usage_run_retention_days`,`Keep run details for`]];function i(e){let t=r.flatMap(([t],n)=>{let r=e?.[t],i=n===0?`request details`:`run details`;return!Number.isInteger(r)||r<0?[]:[r===0?`all ${i}`:`${i} older than ${r} days`]});return t.length?`Shorter Usage retention will delete ${t.join(` and `)}. Usage totals will be kept.`:``}function a(e,t,n){let r=t?.value??t,i=t?.label??String(r);return`<option value="${e._e(String(r))}" ${String(r)===String(n)?`selected`:``}>${e._e(i)}</option>`}function o(e,t,n){let r=e._draft?.[t]??e._result?.config?.[t],i=e._result?.options?.[t]||[];return`<div class="setting" data-field="${t}" data-setting data-search="${e._e(`${n} usage history retention details ${t}`.toLowerCase())}">
    <label for="config-${t}">${e._e(n)}</label>
    <select id="config-${t}" data-config="${t}" data-retention-config="${t}" data-type="number">${i.map(t=>a(e,t,r)).join(``)}</select>
    <small>${t===`usage_request_retention_days`?`Individual provider calls within a conversation turn.`:`Completed conversation turns, including their combined usage and timing.`}</small>
    <span class="field-error" data-error="${t}"></span>
  </div>`}function s(e){return e._configDirty?t({configuration:!0,pending:!!e._configurationSaving}):``}function c(e){return`<section class="page-intro"><h1>Usage data retention</h1><p>Choose how much detailed usage history to keep. Overall totals are maintained separately.</p></section><div class="content-card retention-surface">
    <section id="config-retention" data-config-section data-search="usage history retention request run details totals">
      <div class="card-heading"><div>
        <h2>Retention periods</h2>
        <p>Set separate periods for request and run details. Saving Disabled immediately deletes existing detailed history of that type. Overall usage totals are kept.</p>
      </div></div>
      <div class="form-grid">
        ${r.map(([t,n])=>o(e,t,n)).join(``)}
      </div>
    </section>
    ${s(e)}
    <span id="save-bar-anchor" class="sr-only"></span>
  </div>`}function l(e){let n=e.shadowRoot,r=n?.querySelector?.(`main #save-config`)?.closest(`.save-bar`);if(!e._configDirty){r?.remove?.();return}r||(n?.querySelector?.(`#save-bar-anchor`)?.insertAdjacentHTML(`beforebegin`,t({configuration:!0,pending:!!e._configurationSaving})),d(e))}function u(e){let t=e.shadowRoot;t&&(t.querySelectorAll(`[data-retention-config]`).forEach(t=>{t.addEventListener(`change`,()=>{let r=t.dataset.retentionConfig;r&&e._draft&&(e._draft[r]=Number(t.value),n(e,[r],t,!1),l(e))})}),d(e))}function d(t){let n=t.shadowRoot.querySelector(`#revert-config`);n&&!n.dataset.eocDiscardBound&&(n.dataset.eocDiscardBound=`true`,n.addEventListener(`click`,()=>{!t._configurationSaving&&t._configData?.config&&(e(t),t._eocMainMarkup=null,t._render())}))}export{c as n,i as r,u as t};